package solve;

public class Solve {
	public static void main(String[] args) {
		int[] lista = {1,3,5,6,11,23};
		int sum=9;
		
		int[] answer = twoSum(lista,sum);
		
		System.out.println(answer[0] + " " + answer[1]);
	}
	
	public static int[] twoSum(int[] list, int sum) {
		int[] ret = new int[2];
		
		for(int i = 0; i< list.length;i++) {
			for(int j = 0; j< list.length;j++) {
				if(list[i] + list[j] == sum) {
					ret[0] = list[i];
					ret[1] = list[j];
				}
			}
		}
		
		return ret;
	}
}
