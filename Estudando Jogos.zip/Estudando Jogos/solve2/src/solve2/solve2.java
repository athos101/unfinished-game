package solve2;

public class solve2 {
	public static void main(String[] args) {
		
		System.out.println(digital_root(1234567));
	}
	
	public static int digital_root(int n) {	
		
	      int sum=0;
	      int digit=0;
	      double fractionNum = n;
	      int counter=1;
	    
	      do{
	         fractionNum = fractionNum/10;
	         counter++;
	      }while(fractionNum >= 10);
	      
	      System.out.println("counter:" + counter);
	      
	      for(int i = 0; i < counter; i++){
	        digit = (int)fractionNum;
	        System.out.println("fraction: " + fractionNum + " digit: " + digit);
	        sum += digit;
	        fractionNum -= digit;
	        fractionNum = fractionNum * 10;
	      }
	      
	      if(fractionNum > 0.1) {
	        	sum++;
	        }
	      
	      if(sum >= 10){
	        return digital_root(sum);
	      } else
	        return sum;
	  }
}
