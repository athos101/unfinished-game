package theFramework;

public enum ObjectID {
	Player,Block;
}
