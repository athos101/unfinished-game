package theFramework;

import java.util.LinkedList;
import java.awt.Graphics;
import java.awt.Rectangle;

public abstract class GameObject {
	protected float x,y,velX,velY;
	protected ObjectID id;
	protected boolean falling = true;
	protected boolean jumping = false;
	protected float gravity=0.5f;
	protected boolean aPress, dPress, wPress, sPress;

	public GameObject(float x, float y, ObjectID id) {
		super();
		this.x = x;
		this.y = y;
		this.id = id;
	}
	
	public abstract void update(LinkedList<GameObject> Object);
	public abstract void render(Graphics g);
	
	public Rectangle getBounds() {
		return null;
	}
	
	public Rectangle getBoundsD() {
		return null;
	}
	public Rectangle getBoundsT() {
		return null;
	}
	public Rectangle getBoundsL() {
		return null;
	}
	public Rectangle getBoundsR() {
		return null;
	}
	
	public float getX() {
		return x;
	}
	public float getY(){
		return y;
	}
	public void setX(float x) {
		this.x = x;
	}
	public void setY(float y){
		this.y = y;
	}
	
	public float getVelX() {
		return velX;
	}
	public float getVelY(){
		return velY;
	}
	public void setVelX(float velX) {
		this.velX = velX;
	}
	public void setVelY(float velY){
		this.velY = velY;
	}
	
	public ObjectID getId() {
		return id;
	}

	protected boolean isFalling() {
		return falling;
	}

	protected void setFalling(boolean falling) {
		this.falling = falling;
	}

	protected boolean isJumping() {
		return jumping;
	}

	protected void setJumping(boolean jumping) {
		this.jumping = jumping;
	}
	
	public boolean isaPress() {
		return aPress;
	}

	public void setaPress(boolean aPress) {
		this.aPress = aPress;
	}

	public boolean isdPress() {
		return dPress;
	}

	public void setdPress(boolean dPress) {
		this.dPress = dPress;
	}

	public boolean iswPress() {
		return wPress;
	}

	public void setwPress(boolean wPress) {
		this.wPress = wPress;
	}

	public boolean issPress() {
		return sPress;
	}

	public void setsPress(boolean sPress) {
		this.sPress = sPress;
	}

	public float getGravity() {
		return gravity;
	}

	public void setGravity(float gravity) {
		this.gravity = gravity;
	}
	
}
