package theFramework;
import java.awt.image.BufferedImage;

import theGame.BufferedImageLoader;

public class Texture {
	
	SpriteSheet bs,ps;
	private BufferedImage block_sheet = null;
	private BufferedImage player_sheet = null;
	
	public BufferedImage[] block = new BufferedImage[2];
	public BufferedImage[] player = new BufferedImage[16];
	
	
	public Texture() {
		
		BufferedImageLoader loader = new BufferedImageLoader();
		try {
			block_sheet = loader.loadImage("/imageSource/blocks.png");
			player_sheet = loader.loadImage("/imageSource/PlayerSheet.png");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		bs = new SpriteSheet(block_sheet); 
		ps = new SpriteSheet(player_sheet);
		
		getTextures();
	}
	
	private void getTextures() {
		block[0]=bs.grabImage(1,1,32,32);
		block[1]=bs.grabImage(2,1,32,32);
		
		player[0] = ps.grabImage(1, 1, 72, 116);
		player[1] = ps.grabImage(2, 1, 72, 116);
		player[2] = ps.grabImage(3, 1, 72, 116);
		player[3] = ps.grabImage(4, 1, 72, 116);
		player[4] = ps.grabImage(1, 2, 72, 116);
		player[5] = ps.grabImage(2, 2, 72, 116);
		player[6] = ps.grabImage(3, 2, 72, 116);
		player[7] = ps.grabImage(4, 2, 72, 116);
		
		player[8] = ps.grabImage(5, 1, 72, 116);
		player[9] = ps.grabImage(6, 1, 72, 116);
		player[10] = ps.grabImage(7, 1, 72, 116);
		player[11] = ps.grabImage(8, 1, 72, 116);
		player[12] = ps.grabImage(5, 2, 72, 116);
		player[13] = ps.grabImage(6, 2, 72, 116);
		player[14] = ps.grabImage(7, 2, 72, 116);
		player[15] = ps.grabImage(8, 2, 72, 116);
	}
}
