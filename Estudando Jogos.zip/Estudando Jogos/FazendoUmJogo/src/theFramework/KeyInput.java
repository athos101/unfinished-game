package theFramework;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import theGame.Handler;

public class KeyInput extends KeyAdapter{
	Handler handler;
	
	public KeyInput(Handler handler) {
		this.handler = handler;
	}
	
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		
		for(int i=0;i<handler.object.size();i++) {
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getId() == ObjectID.Player) {
				if(key == KeyEvent.VK_D) {
					tempObject.setdPress(true);
					
				}
				
				if(key == KeyEvent.VK_A) {
					tempObject.setaPress(true);
					
				}
				
				if(key == KeyEvent.VK_SPACE && !tempObject.isJumping()) {
					tempObject.setJumping(true);
				}
			}
		}
	}	
	
	public void keyReleased(KeyEvent e) {
int key = e.getKeyCode();
		
		for(int i=0;i<handler.object.size();i++) {
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getId() == ObjectID.Player) {
				if(key == KeyEvent.VK_D) tempObject.setdPress(false);
				if(key == KeyEvent.VK_A) tempObject.setaPress(false);
				if(key == KeyEvent.VK_SPACE) {
					tempObject.setJumping(false);
				}
			}
		}
	}
}
