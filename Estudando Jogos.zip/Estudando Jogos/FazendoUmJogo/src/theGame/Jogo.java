package theGame;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.util.Random;
import java.awt.image.BufferedImage;

import objects.Block;
import objects.Player;
import theFramework.KeyInput;
import theFramework.ObjectID;
import theFramework.Texture;

public class Jogo extends Canvas implements Runnable {

// SERIALV + RUNNING + THREAD =============================================	

	private static final long serialVersionUID = -5337885585216741650L;
	private boolean running;
	// Not obligatory, just to not initialize more than one time.
	Thread thread;

	public static int WIDTH, HEIGHT;

	// FOR OBJECTS
	Handler handler;
	Camera cam;
	Random rand = new Random();
	private BufferedImage level = null;
	static Texture tex;

// INITIALIZATION =============================================================	

	public void init() {
		WIDTH = getWidth();
		HEIGHT = getHeight();
		
		tex = new Texture();

		BufferedImageLoader loader = new BufferedImageLoader();
		level = loader.loadImage("/imageSource/draw.png"); //LOADING THE LEVEL
		
		cam = new Camera(0, 0);

		handler = new Handler();
		
		LoadImageLevel(level);

		handler.addObject(new Player(100, 100,handler, ObjectID.Player));
		//handler.createLevel();

		this.addKeyListener(new KeyInput(handler));
	}

	public static Texture getInstance() {
		return tex;
	}
	
// 	MAIN ===================================================================

	public static void main(String[] args) {
		new Window(960, 640, "Jogo Rodando", new Jogo());
	}

// START + RUNNING ==========================================================

	public void start() {
		if (running) {
			return; // Not initialize twice.
		}
		running = true;
		thread = new Thread(this);
		// Referring to itself because the the class implements Runnable.

		thread.start(); // Here we initialize the program.
	}

	@Override
	public void run() {
		System.out.println("Is running.");
		init();
		this.requestFocus();
		gameLoop();
	}

// UPDATE ==================================================================

	protected void update() {
		handler.update();
		for (int i = 0; i < handler.object.size(); i++)
			if (handler.object.get(i).getId() == ObjectID.Player)
				cam.update(handler.object.get(i));
	}

// RENDER ==================================================================

	protected void render() {

		BufferStrategy buffer = this.getBufferStrategy();
		if (buffer == null) {
			this.createBufferStrategy(3);
			return;
		}

		Graphics g = buffer.getDrawGraphics();
		Graphics2D g2d = (Graphics2D) g;  

		// ---- DRAW SECTION ---------------------

		g.setColor(new Color(171, 255, 231)); // SET BACKGRUND COLOR
		g.fillRect(0, 0, getWidth(), getHeight());

		g2d.translate(cam.getX(), cam.getY()); // CAMERA BEGINNING

		handler.render(g);

		g2d.translate(-cam.getX(), -cam.getY()); // CAMERA END
		

		// ---- DRAW SECTION ---------------------

		g.dispose();
		buffer.show();
	}

	private void LoadImageLevel(BufferedImage image) {
		int w = image.getWidth();
		int h = image.getHeight();
		
		for(int xx=0; xx<h ;xx++) {
			for(int yy=0;yy<w;yy++) {
				int pixel = image.getRGB(xx,yy);
				int red = (pixel >> 16) & 0xff;
				int green = (pixel >> 8) & 0xff;
				int blue = (pixel) & 0xff;
				
				if(red == 255 && green == 255 && blue == 255) {
					handler.addObject(new Block(1 + xx*32, 1 + yy*32,0,ObjectID.Block));
				}
			}
		}
		
	}
	
// GAME LOOP ===============================================================

	protected void gameLoop() {

		int FPS = 60;
		long intervalo = 1000000000 / FPS;
		long lastTime = System.nanoTime();
		long currentTime = 0;
		double delta = 0;
		int renderCounter = 0;
		long timer = 0;

		while (running) {
			currentTime = System.nanoTime();
			delta += currentTime - lastTime;
			timer += currentTime - lastTime;
			lastTime = currentTime;

			if (delta >= intervalo) {
				update();
				render();
				renderCounter++;
				delta -= intervalo;
			}

			if (timer >= 1000000000) {
				System.out.println(" FPS: " + renderCounter);
				renderCounter = 0;
				timer -= 1000000000;
			}

		}

	}
}