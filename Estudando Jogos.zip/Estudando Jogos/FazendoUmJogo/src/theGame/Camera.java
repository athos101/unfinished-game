package theGame;

import theFramework.GameObject;

public class Camera {
	private float x,y;
	
	public Camera(float x, float y) {
		this.x = x;
		this.y = y;
	}

	public void update(GameObject player) {
		x = -(int)player.getX() + Jogo.WIDTH/2;
		y = -(int)player.getY() + Jogo.HEIGHT/2;
	}
	
	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}
	
	
}
