package theGame;
import java.awt.Dimension;
import javax.swing.JFrame;
public class Window {
	
	public Window(int width, int height, String title, Jogo jogo) {
		jogo.setPreferredSize(new Dimension(width,height));
		jogo.setMaximumSize(new Dimension(width,height));
		jogo.setMinimumSize(new Dimension(width,height));
		
		JFrame frame = new JFrame();
		frame.add(jogo);
		frame.setResizable(false);
		frame.setTitle(title);
		frame.setVisible(true);
		frame.setLocation(100,100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		
		jogo.start();
	}
	
}
