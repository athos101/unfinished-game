package objects;
import java.awt.Graphics;
import java.util.LinkedList;

import theFramework.GameObject;
import theFramework.ObjectID;
import theFramework.Texture;
import theGame.Animation;
import theGame.Handler;
import theGame.Jogo;

import java.awt.*;

public class Player extends GameObject{
	
	private float width = 72, height = 110;
	private final float MAX_VEL=40;
	private Handler handler;
	private boolean jumpset;
	private long saveTime;
	
	Texture tex = Jogo.getInstance();
	private Animation playerWalk;
	private Animation playerWalk2;
	
	public Player(float x, float y, Handler handler, ObjectID id) {
		super(x, y, id);
		this.handler = handler;
		
		playerWalk = new Animation(6,tex.player[0],tex.player[1],tex.player[2],tex.player[3],tex.player[4],tex.player[5],tex.player[6],tex.player[7]);																																																																		
		playerWalk2 = new Animation(6,tex.player[8],tex.player[9],tex.player[10],tex.player[11],tex.player[12],tex.player[13],tex.player[14],tex.player[15]);																																																			
	}

	private void movement() {
		if(aPress) {
			velX = -6;
		}
		if(dPress) {
			velX = 6;
		}
		if(dPress && aPress || !dPress && !aPress) {
			velX *= 0.8;
		}
		
		if(jumping && jumpset) {
			velY = -12;
			jumpset=false;
		}
	}
	
	@Override
	public void update(LinkedList<GameObject> object) {
	
		movement();
		
		x += velX;
		y += velY;
		
		if(falling || jumping) {
			velY += gravity;
			if(velY > MAX_VEL) {
				velY = MAX_VEL;
			}
		}
		
		playerWalk.runAnimation();
		playerWalk2.runAnimation();
		collision(object);
	}
	
	private void collision(LinkedList<GameObject> object) {
		for(int i=0;i<handler.object.size();i++) {
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getId() == ObjectID.Block) {
				
				if(getBounds().intersects(tempObject.getBounds())){
					y = tempObject.getY() - height + gravity;
					velY = 0;
					falling = false;
					jumpset = true;
					saveTime = System.nanoTime();
				}else
					if(System.nanoTime()-saveTime >= 100000000) {
						jumpset=false;
						falling = true;
					}

				if(getBoundsT().intersects(tempObject.getBounds())) {
					y = tempObject.getY() + tempObject.getBounds().height;
					velY = 0;
				}
				
				if(getBoundsR().intersects(tempObject.getBounds())) {
					x = tempObject.getX() - width;
					velX = 0;
				}
				
				if(getBoundsL().intersects(tempObject.getBounds())) {
					x = tempObject.getX() + tempObject.getBounds().width;
					velX = 0;
				}
			}
		}
	}

	@Override
	public void render(Graphics g) {

		g.setColor(Color.blue);
		
		if(velX > 0.2)
			playerWalk.drawAnimation(g, (int)x, (int)y, (int)width,(int) height);
		else if(velX < -0.2)
			playerWalk2.drawAnimation(g, (int)x, (int)y, (int)width,(int) height);
		else
			g.drawImage(tex.player[0],(int)x,(int)y,(int)width,(int)height,null);
		
		//Graphics2D g2d = (Graphics2D)g;
		
		g.setColor(Color.red);
		
		/*
		 g2d.draw(getBounds());
		g2d.draw(getBoundsT());
		g2d.draw(getBoundsR());
		g2d.draw(getBoundsL());
		 */
		
	}
	
	public Rectangle getBounds() {
		return new Rectangle((int)(x + (width/2)-(width/4)),(int)(y + (height/2)),(int)width/2,(int)(height/2));
	}
	
	public Rectangle getBoundsT() {
		return new Rectangle((int)(x + (width/2)-(width/4)),(int)y,(int)width/2,(int)height/2);
	}
	
	public Rectangle getBoundsR() {
		return new Rectangle((int)(x+width-5),(int)(y+5),(int)5,(int)(height-10));
	}
	
	public Rectangle getBoundsL() {
		return new Rectangle((int)x,(int)(y+5),(int)5,(int)(height-10));
	}
	
	

}
